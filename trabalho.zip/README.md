# 20242-team-9

INF 112 - TRABALHO FINAL

INTEGRANTES DO GRUPO:

Kayo de Melo Lage - 116211
Rafael Tavares de Almeida - 116231
Matheus Gabriel Rocha Souza - 116221

TEMA: Jogo de RPG (especificamente, um RPG de cartas)