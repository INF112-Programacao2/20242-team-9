#include "GameManager.h"

int main() {
    GameManager manager;
    manager.run();
    return EXIT_SUCCESS;
}


