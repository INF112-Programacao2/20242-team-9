#ifndef ESTADO_JOGO_H
#define ESTADO_JOGO_H

enum class EstadoJogo{
    Menu,
    Jogando,
    Opcoes,
    Sair
};

#endif