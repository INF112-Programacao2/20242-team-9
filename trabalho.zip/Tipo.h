#ifndef TIPO_H
#define TIPO_H

enum class Tipo{
    AbelhaRainha,
    AbelhaOperaria,
    Barata,
    Besouro,
    CupimRei,
    CupimSoldado,
    Cigarra,
    LouvaDeus,
    Gafanhoto,
    FormigaRainha,
    FormigaZangao
};

#endif